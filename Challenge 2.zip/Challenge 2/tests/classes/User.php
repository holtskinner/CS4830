<?php
class User {
    public $name;

    public function User($name = ''){
        $this->name = $name;
    }
}